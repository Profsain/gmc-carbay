Component Lifecycle

1- mounting
2- updating
3- unmounting