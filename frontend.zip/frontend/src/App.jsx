import AddTeamForm from "./components/addcar/AddTeamForm";
import TeamList from "./components/team/TeamList";

const App = () => {

 
  return (
    <div>
      <h1>Car Listing Bay</h1>

      <TeamList />


      <div>
        <AddTeamForm />
      </div>

    </div>
  );
};

export default App;
